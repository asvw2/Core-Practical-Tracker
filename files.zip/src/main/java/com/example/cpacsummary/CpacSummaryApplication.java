package com.example.cpacsummary;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CpacSummaryApplication {
    public static void main(String[] args) {
        SpringApplication.run(CpacSummaryApplication.class, args);
    }
}